Trade Bridge Connect™ - Live Shipping Tracker

✅ Phase 1 Setup Instructions:
1. Install Node.js and run:
   npm install express node-fetch cors

2. Start server:
   node server.js

3. Open index.html in your browser (double-click or drag into browser).

4. Use container number to test tracking.

🌐 Features:
- Track by Container / BL / Booking (input only affects label, not API yet)
- Default fallback to show map always
- User-friendly errors and layout
